const Utils = require("../modules/utils");

module.exports = async (bot, invite) => {
    Utils.updateInviteCache(bot)
}
// 239232   8501   2229706    63250   1613689679   NULLED BY 0xEB   2229706
Category_Name: "General"
Bot_Count: true
Human_Count: true
Total_Members_Count: true
Channel_Count: true
Lang:
  Bots: "Bots: "
  Humans: "Humans: "
  Total_Members: "Total Members: "
  Channels: "Channels: "